﻿namespace Kolokwium
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj liczbę przedmiotów na świadectwie: ");
            int liczbaPrzedmiotow = Convert.ToInt32(Console.ReadLine());

            Swiadectwo s1 = new Swiadectwo(liczbaPrzedmiotow);

            s1.Wczytaj();

            s1.Wypisz();

            if (s1.Promocja()) Console.WriteLine($"Uzyskano Promocję! Średnia ocen: {s1.Srednia()}");
            else Console.WriteLine("Zostajesz w klasie :c");
        }
    }
}