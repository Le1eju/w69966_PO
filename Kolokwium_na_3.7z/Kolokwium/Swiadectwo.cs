﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokwium
{
    internal class Swiadectwo : ICloneable
    {
        private int ile {  get; set; }
        private List<Przedmiot> przedmioty {get; set;}
        public Swiadectwo(int x)
        {
            przedmioty = new List<Przedmiot>();
            for (int i = 0; i < x; i++)
            {
                przedmioty.Add(new Przedmiot());
            }
        }

        #region ICloneable Members
        public new Swiadectwo Clone() { return new Swiadectwo(ile); }
        object ICloneable.Clone() { return Clone(); }

        #endregion

        public void Wczytaj()
        {
            foreach (var p in przedmioty)
            {
                p.Wczytaj();
            }
        }
        public double Srednia()
        {
            double sum = 0;
            foreach (var p in przedmioty)
            {
                sum += p.Ocena();
            }
            return Math.Round(sum / przedmioty.Count(), 2);
        }
        public bool Promocja()
        {
            foreach (var p in przedmioty)
            {
                if (p.Ocena() <= 2) return false;
            }
            return true;
        }
        public void Wypisz()
        {
            foreach (var p in przedmioty)
            {
                p.Wypisz();
            }
        }
    }
}
