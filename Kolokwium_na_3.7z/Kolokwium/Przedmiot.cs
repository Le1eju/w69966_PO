﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokwium
{
    internal class Przedmiot
    {
        private string nazwa { get; set; }
        private int ocena { get; set; }

        public Przedmiot()
        {
            nazwa = "";
            ocena = 0;
        }
        public Przedmiot(string x, int y)
        {
            while (true)
            {
                try
                {
                    if (y != 0 || y != 2 || y != 3 || y != 4 || y != 5)
                    {
                        throw new ArgumentException("Podano nieprawidłą ocenę!\n" +
                            "0 - brak oceny\n" +
                            "2 - niedostateczny\n" +
                            "3 - dostateczny\n" +
                            "4 - dobry\n" +
                            "5 - bardzo dobry");
                    }
                    else ocena = y;
                    break;
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"{ex.Message}");
                }
            }
            nazwa = x;
        }

        public int Ocena()
        {
            return ocena;
        }
        public void Wczytaj()
        {
            Console.WriteLine("Podaj nazwę przedmiotu: ");
            nazwa = Console.ReadLine();

            Console.WriteLine("Podaj ocenę: ");
            ocena = Convert.ToInt32(Console.ReadLine());
        }
        public void Wypisz()
        {
            Console.WriteLine($"Przedmiot: {this.nazwa}\tOcena: {this.ocena}");
        }


    }
}
